IF OBJECT_ID('dbo.trip') IS NOT NULL
BEGIN
DROP EXTERNAL TABLE [dbo].[trip];
END

IF NOT EXISTS (SELECT * FROM sys.external_file_formats WHERE name = 'SynapseDelimitedTextFormat') 
	CREATE EXTERNAL FILE FORMAT [SynapseDelimitedTextFormat] 
	WITH ( FORMAT_TYPE = DELIMITEDTEXT ,
	       FORMAT_OPTIONS (
			 FIELD_TERMINATOR = ',',
			 USE_TYPE_DEFAULT = FALSE
			))
GO

IF NOT EXISTS (SELECT * FROM sys.external_data_sources WHERE name = 'synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net') 
	CREATE EXTERNAL DATA SOURCE [synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net] 
	WITH (
		LOCATION = 'abfss://synapsefilekhanhnh17@synapsekhanhnh17.dfs.core.windows.net' 
	)
GO

CREATE EXTERNAL TABLE dbo.trip (
	[trip_id] VARCHAR(50),
	[rideable_type] VARCHAR(75),
	[start_at] TIMESTAMP,
	[ended_at] TIMESTAMP,
	[start_station_id] VARCHAR(50),
	[end_station_id] VARCHAR(50),
	[rider_id] int
	)
	WITH (
	LOCATION = 'trips.csv',
	DATA_SOURCE = [synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net],
	FILE_FORMAT = [SynapseDelimitedTextFormat]
	)
GO

SELECT [trip_id],[rideable_type],[start_at],[ended_at],[start_station_id],[end_station_id],[rider_id]
FROM dbo.trip
GO