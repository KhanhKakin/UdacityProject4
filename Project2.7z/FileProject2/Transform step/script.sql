-- Create trip table
CREATE TABLE trip (
  trip_id INT NOT NULL PRIMARY KEY,
  rideable_type VARCHAR(75),
  start_at TIMESTAMP,
  ended_at TIMESTAMP,
  start_station_id VARCHAR(50),
  end_station_id VARCHAR(50),
  rider_id INT
);

-- Create trip_fact table
CREATE TABLE trip_fact (
  trip_fact_id INT NOT NULL PRIMARY KEY,
  trip_id INT,
  rider_id INT,
  station_id_start VARCHAR(50),
  station_id_end VARCHAR(50),
  date_id VARCHAR(50),
  trip_duration INT,
  rider_age_at_trip INT
);

-- Create payment table
CREATE TABLE payment (
  payment_id INT NOT NULL PRIMARY KEY,
  date DATE,
  amount MONEY,
  rider_id INT
);

-- Create payment_fact table
CREATE TABLE payment_fact (
  payment_fact_id INT NOT NULL PRIMARY KEY,
  payment_id INT,
  rider_id INT,
  station_id MONEY,
  date_id VARCHAR(50),
  payment_amount_fact MONEY,
  payment_method VARCHAR(50)
);

-- Create station table
CREATE TABLE station (
  station_id INT NOT NULL PRIMARY KEY,
  name VARCHAR(75),
  latitude FLOAT,
  longitude FLOAT
);

-- Create rider table
CREATE TABLE rider (
  rider_id INT NOT NULL PRIMARY KEY,
  first VARCHAR(50),
  last VARCHAR(50),
  address VARCHAR(100),
  birthday DATE,
  account_start_date DATE,
  account_end_date DATE,
  is_member BIT
);