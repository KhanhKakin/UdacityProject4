IF OBJECT_ID('dbo.trip_fact') IS NOT NULL
BEGIN
DROP EXTERNAL TABLE [dbo].[trip_fact];
END

IF NOT EXISTS (SELECT * FROM sys.external_file_formats WHERE name = 'SynapseDelimitedTextFormat') 
	CREATE EXTERNAL FILE FORMAT [SynapseDelimitedTextFormat] 
	WITH ( FORMAT_TYPE = DELIMITEDTEXT ,
	       FORMAT_OPTIONS (
			 FIELD_TERMINATOR = ',',
			 USE_TYPE_DEFAULT = FALSE
			))
GO

IF NOT EXISTS (SELECT * FROM sys.external_data_sources WHERE name = 'synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net') 
	CREATE EXTERNAL DATA SOURCE [synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net] 
	WITH (
		LOCATION = 'abfss://synapsefilekhanhnh17@synapsekhanhnh17.dfs.core.windows.net' 
	)
GO

CREATE EXTERNAL TABLE dbo.trip_fact (
    [trip_fact_id] INT,
	[trip_id] INT,
    [rider_id] INT,
    [station_id_start] VARCHAR(50),
    [station_id_end] VARCHAR(50),
	[date_id] VARCHAR(50),
	[trip_duration] INT,
	[rider_age_at_trip] INT,
	[end_station_id] VARCHAR(50)
	)
	WITH (
	LOCATION = 'trip_fact.csv',
	DATA_SOURCE = [synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net],
	FILE_FORMAT = [SynapseDelimitedTextFormat]
	)
GO

SELECT *
FROM dbo.trip_fact
GO