IF OBJECT_ID('dbo.rider') IS NOT NULL
BEGIN
DROP EXTERNAL TABLE [dbo].[rider];
END

IF NOT EXISTS (SELECT * FROM sys.external_file_formats WHERE name = 'SynapseDelimitedTextFormat') 
	CREATE EXTERNAL FILE FORMAT [SynapseDelimitedTextFormat] 
	WITH ( FORMAT_TYPE = DELIMITEDTEXT ,
	       FORMAT_OPTIONS (
			 FIELD_TERMINATOR = ',',
			 USE_TYPE_DEFAULT = FALSE
			))
GO

IF NOT EXISTS (SELECT * FROM sys.external_data_sources WHERE name = 'synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net') 
	CREATE EXTERNAL DATA SOURCE [synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net] 
	WITH (
		LOCATION = 'abfss://synapsefilekhanhnh17@synapsekhanhnh17.dfs.core.windows.net' 
	)
GO

CREATE EXTERNAL TABLE dbo.rider (
	[rider_id] INT,
	[first] VARCHAR(50),
	[last] VARCHAR(50),
	[address] VARCHAR(100),
	[birthday] DATE,
	[account_start_date] DATE,
	[account_end_date] DATE,
	[is_member] bit
	)
	WITH (
	LOCATION = 'riders.csv',
	DATA_SOURCE = [synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net],
	FILE_FORMAT = [SynapseDelimitedTextFormat]
	)
GO

SELECT [rider_id],[first],[last],[address],[birthday],[account_start_date],[account_end_date],[is_member]
FROM dbo.rider
GO