IF NOT EXISTS (SELECT * FROM sys.external_file_formats WHERE name = 'SynapseDelimitedTextFormat') 
	CREATE EXTERNAL FILE FORMAT [SynapseDelimitedTextFormat] 
	WITH ( FORMAT_TYPE = DELIMITEDTEXT ,
	       FORMAT_OPTIONS (
			 FIELD_TERMINATOR = ',',
			 USE_TYPE_DEFAULT = FALSE
			))
GO

IF NOT EXISTS (SELECT * FROM sys.external_data_sources WHERE name = 'synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net') 
	CREATE EXTERNAL DATA SOURCE [synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net] 
	WITH (
		LOCATION = 'abfss://synapsefilekhanhnh17@synapsekhanhnh17.dfs.core.windows.net' 
	)
GO

CREATE EXTERNAL TABLE dbo.rider (
	[C1] bigint,
	[C2] nvarchar(4000),
	[C3] nvarchar(4000),
	[C4] nvarchar(4000),
	[C5] date,
	[C6] date,
	[C7] date,
	[C8] bit
	)
	WITH (
	LOCATION = 'riders.csv',
	DATA_SOURCE = [synapsefilekhanhnh17_synapsekhanhnh17_dfs_core_windows_net],
	FILE_FORMAT = [SynapseDelimitedTextFormat]
	)
GO


SELECT TOP 100 * FROM dbo.rider
GO